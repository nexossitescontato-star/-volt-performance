import { useEffect, useState } from "react";
const links = [["Início", "inicio"], ["Modalidades", "modalidades"], ["Estrutura", "estrutura"], ["Planos", "planos"], ["Equipe", "equipe"], ["Contato", "contato"]];
export default function Navbar() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const f = () => setSolid(window.scrollY > 40);
    f(); window.addEventListener("scroll", f, { passive: true }); return () => window.removeEventListener("scroll", f);
  }, []);
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; }, [open]);
  return (
    <nav className={`fixed inset-x-0 top-0 z-50 px-5 py-3.5 transition ${solid ? "border-b border-white/10 bg-ink/90 backdrop-blur-lg" : ""}`}>
      <div className="mx-auto flex max-w-[1160px] items-center justify-between">
        <a href="#inicio" className="font-display text-2xl leading-[.9] tracking-wider">VOLT<small className="block font-sans text-[.55rem] font-bold tracking-[.42em] text-volt">PERFORMANCE</small></a>
        <button aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)} className="z-10 flex h-11 w-11 flex-col items-center justify-center gap-1.5 md:hidden">
          <i className={`h-0.5 w-6 bg-white transition ${open ? "translate-y-2 rotate-45" : ""}`} /><i className={`h-0.5 w-6 bg-white transition ${open ? "opacity-0" : ""}`} /><i className={`h-0.5 w-6 bg-white transition ${open ? "-translate-y-2 -rotate-45" : ""}`} />
        </button>
        <div className={`fixed inset-0 flex flex-col items-center justify-center gap-6 bg-ink text-xl transition-transform duration-300 md:static md:flex-row md:gap-7 md:bg-transparent md:text-[.78rem] md:translate-x-0 ${open ? "translate-x-0" : "translate-x-full"}`}>
          {links.map(([l, id]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)} className="font-semibold uppercase tracking-[.14em] text-[#cfd5e2] transition hover:text-cyan2">{l}</a>)}
        </div>
      </div>
    </nav>
  );
}
