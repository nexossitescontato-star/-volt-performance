import { CONFIG } from "../../config";
import Btn from "../ui/Btn";
import Reveal from "../ui/Reveal";
export default function Contact() {
  return (
    <section id="contato" className="bg-[radial-gradient(ellipse_at_50%_100%,rgba(43,123,255,.28),transparent_60%)] px-5 py-24 text-center">
      <Reveal>
        <p className="mb-3.5 text-xs font-bold uppercase tracking-[.3em] text-volt">Contato</p>
        <h2 className="mb-4 text-[clamp(2.2rem,7vw,4rem)]">PRONTO PARA COMEÇAR?</h2>
        <p className="mb-8 text-lg text-[#b6bdcb]">Seu próximo nível começa com uma decisão.</p>
        <div className="flex flex-wrap justify-center gap-3"><Btn href={CONFIG.whatsapp} external>FALAR NO WHATSAPP</Btn><Btn href={CONFIG.instagram} external ghost>INSTAGRAM</Btn></div>
      </Reveal>
    </section>
  );
}
