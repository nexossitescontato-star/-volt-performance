export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { volt: "#2b7bff", cyan2: "#00c2ff", ink: "#050608", panel: "#0b0e14" },
    fontFamily: { display: ["Impact", "Arial Narrow Bold", "sans-serif"] },
  } },
  plugins: [],
};
