/** Links placeholder — edite aqui */
export const CONFIG = {
  whatsapp: "https://wa.me/5500000000000?text=Ol%C3%A1%2C%20quero%20saber%20mais%20sobre%20a%20VOLT",
  instagram: "https://instagram.com/seu_perfil_aqui",
};
/** Todas as imagens em um só lugar. Vazio = gradiente. Cole URLs de fotos de academia. */
export const IMG: Record<string, string> = {
  hero: "", quote: "", musculacao: "", funcional: "", hiit: "", personal: "", cardio: "",
  pesos: "", recepcao: "", interno: "", equipe1: "", equipe2: "", equipe3: "",
};
const G = [["#0a1a3a", "#2b7bff"], ["#06121f", "#00c2ff"], ["#12122b", "#4a5cff"], ["#08202e", "#1b8fff"], ["#0b0f1e", "#2563ff"]];
export const bg = (k: string, i = 0): string => {
  const g = G[i % G.length];
  return `${IMG[k] ? `url(${IMG[k]}),` : ""}radial-gradient(circle at 70% 20%,${g[1]}66,transparent 55%),linear-gradient(160deg,${g[0]},#050608)`;
};
export const mods = [
  { k: "musculacao", t: "MUSCULAÇÃO", d: "Estrutura completa para força, hipertrofia e evolução." },
  { k: "funcional", t: "FUNCIONAL", d: "Movimento, resistência e condicionamento em treinos dinâmicos." },
  { k: "hiit", t: "HIIT", d: "Treinos de alta intensidade para quem busca desafiar seus limites." },
  { k: "personal", t: "PERSONAL", d: "Acompanhamento individualizado de acordo com seus objetivos." },
];
export const slides = [...mods, { k: "cardio", t: "CARDIO", d: "Resistência e fôlego com equipamentos de ponta." }];
export const areas = [
  { k: "musculacao", t: "Área de musculação", d: "Máquinas e estações para todos os grupos musculares." },
  { k: "pesos", t: "Pesos livres", d: "Halteres, barras e anilhas em espaço amplo." },
  { k: "cardio", t: "Área de cardio", d: "Esteiras, bikes e elípticos de última geração." },
  { k: "funcional", t: "Área funcional", d: "Piso livre para circuitos e treinos dinâmicos." },
  { k: "recepcao", t: "Recepção", d: "Atendimento acolhedor desde a chegada." },
  { k: "interno", t: "Espaço interno", d: "Iluminação e ambiente pensados para foco." },
];
export const plans = [
  { t: "PLANO START", d: "Acesso à musculação e cardio.", hot: false },
  { t: "PLANO PERFORMANCE", d: "Musculação + cardio + funcional.", hot: true },
  { t: "PLANO PRIME", d: "Acesso completo + benefícios exclusivos.", hot: false },
];
export const team = [
  { n: "Lucas Almeida", r: "Personal Trainer", k: "equipe1" },
  { n: "Marina Costa", r: "Personal Trainer", k: "equipe2" },
  { n: "Rafael Santos", r: "Professor de Funcional", k: "equipe3" },
];
