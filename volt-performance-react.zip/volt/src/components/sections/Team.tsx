import { bg, team } from "../../config";
import Heading from "../ui/Heading";
export default function Team() {
  return (
    <section id="equipe" className="px-5 py-24"><div className="mx-auto max-w-[1160px]">
      <Heading eyebrow="Equipe" title="QUEM ESTÁ COM VOCÊ" lead="Profissionais fictícios criados para este projeto demonstrativo." />
      <div className="grid gap-4 md:grid-cols-3">
        {team.map((t, i) => (
          <article key={t.n} className="relative flex h-[400px] flex-col justify-end overflow-hidden border border-white/10 bg-cover p-5" style={{ backgroundImage: bg(t.k, i) }}>
            <span className="absolute left-3.5 top-3.5 border border-white/30 bg-black/50 px-2 py-0.5 text-[.6rem] tracking-[.15em]">PERSONAGEM FICTÍCIO</span>
            <div className="absolute left-1/2 top-1/4 h-28 w-28 -translate-x-1/2 rounded-full border border-white/15 bg-[radial-gradient(circle_at_35%_30%,rgba(43,123,255,.6),rgba(255,255,255,.04))]" />
            <h3 className="relative text-2xl">{t.n}</h3><span className="relative text-xs uppercase tracking-[.14em] text-cyan2">{t.r}</span>
          </article>
        ))}
      </div>
    </div></section>
  );
}
