import Heading from "../ui/Heading";
export default function Location() {
  return (
    <section id="local" className="px-5 py-24"><div className="mx-auto max-w-[1160px]">
      <Heading eyebrow="Localização" title="ENCONTRE A VOLT" />
      <div className="grid gap-8 md:grid-cols-[1fr_1.3fr]">
        <div className="text-[#8b93a3]">
          <p className="mb-2 font-semibold text-white">Av. Performance, 100 — Centro</p><p className="mb-2">Vitória de Santo Antão — PE</p><p>Aberta 24 horas, todos os dias.</p>
          <span className="mt-5 inline-block border border-dashed border-[#3a4152] px-3 py-1.5 text-[.7rem] tracking-[.16em]">ENDEREÇO FICTÍCIO · PROJETO DEMONSTRATIVO</span>
        </div>
        <div className="relative min-h-[300px] overflow-hidden border border-white/10 bg-panel" role="img" aria-label="Mapa estilizado ilustrativo">
          <svg viewBox="0 0 600 340" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full">
            <path d="M0 80H600M0 170H600M0 260H600M120 0V340M280 0V340M440 0V340" stroke="#1b2130" strokeWidth="2" fill="none" />
            <path d="M0 250L200 170L320 150L600 60" stroke="#2b7bff" strokeOpacity=".55" strokeWidth="4" fill="none" />
            <g fill="#0f1420"><rect x="140" y="95" width="120" height="60" /><rect x="300" y="190" width="120" height="55" /><rect x="460" y="100" width="100" height="55" /></g>
          </svg>
          <span className="absolute left-[52%] top-[46%] h-4 w-4 animate-ping rounded-full bg-volt" /><span className="absolute left-[52%] top-[46%] h-4 w-4 rounded-full bg-volt shadow-[0_0_40px_#2b7bff]" />
        </div>
      </div>
    </div></section>
  );
}
