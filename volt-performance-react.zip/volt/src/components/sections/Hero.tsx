import { useEffect, useState } from "react";
import { bg } from "../../config";
import Btn from "../ui/Btn";
export default function Hero() {
  const [y, setY] = useState(0);
  useEffect(() => {
    const f = () => setY(window.scrollY < window.innerHeight ? window.scrollY : 0);
    window.addEventListener("scroll", f, { passive: true }); return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <header id="inicio" className="relative flex min-h-svh items-center overflow-hidden px-5 pb-16 pt-28">
      <div className="absolute -inset-y-[8%] inset-x-0" style={{ backgroundImage: bg("hero", 1), backgroundSize: "cover", backgroundPosition: "center", transform: `translateY(${y * 0.25}px)` }} />
      <div className="absolute inset-0 bg-gradient-to-r from-ink/90 to-ink/40" />
      <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
      <div className="relative z-10 mx-auto w-full max-w-[1160px]">
        <p className="mb-2 text-xs font-bold uppercase tracking-[.3em] text-volt">Academia · Treino · Tecnologia</p>
        <h1 className="mb-6 text-[clamp(3.6rem,15vw,9rem)]">VOLT<br /><span className="text-volt [text-shadow:0_0_40px_rgba(43,123,255,.5)]">PERFORMANCE</span></h1>
        <p className="mb-8 max-w-[480px] text-lg text-[#d3d8e3]"><b className="mb-2 block font-display text-2xl tracking-wider">SUPERE SEU LIMITE.</b>Treine com estrutura, intensidade e acompanhamento para evoluir todos os dias.</p>
        <div className="flex flex-wrap gap-3"><Btn href="#carrossel">CONHEÇA A VOLT</Btn><Btn href="#planos" ghost>VER PLANOS</Btn></div>
        <div className="mt-14 flex flex-wrap gap-x-9 gap-y-3 border-t border-white/10 pt-6 text-xs uppercase tracking-[.14em] text-[#8b93a3]">
          {[["24/7", "Acesso livre"], ["PRO", "Equipamentos profissionais"], ["EXPERT", "Acompanhamento especializado"]].map(([a, b]) => <div key={a}><b className="block font-display text-2xl text-white">{a}</b>{b}</div>)}
        </div>
      </div>
    </header>
  );
}
