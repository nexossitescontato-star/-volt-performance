import CoverflowCarousel from "../ui/3-d-coverflow-carousel";
import Heading from "../ui/Heading";
import { CONFIG, bg, slides } from "../../config";
export default function Showcase() {
  const items = slides.map((s, i) => ({ id: s.k, title: s.t, text: s.d, image: bg(s.k, i) }));
  return (
    <section id="carrossel" className="bg-panel pt-24">
      <div className="mx-auto max-w-[1160px] px-5"><Heading eyebrow="Explore" title="SENTIR A VOLT." lead="Arraste, use as setas ou o teclado para navegar pelas áreas de treino." /></div>
      <div className="-mt-20"><CoverflowCarousel items={items} ctaLabel="EXPERIMENTAR" ctaHref={CONFIG.whatsapp} /></div>
    </section>
  );
}
