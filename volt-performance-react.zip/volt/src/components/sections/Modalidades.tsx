import { bg, mods } from "../../config";
import Heading from "../ui/Heading";
import Reveal from "../ui/Reveal";
export default function Modalidades() {
  return (
    <section id="modalidades" className="px-5 py-24"><div className="mx-auto max-w-[1160px]">
      <Heading eyebrow="Modalidades" title="TREINE DO SEU JEITO." lead="Diferentes formas de treinamento para cada objetivo, nível e rotina." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {mods.map((m, i) => (
          <Reveal key={m.k}><article className="group relative flex h-[380px] flex-col justify-end overflow-hidden border border-white/10 p-6">
            <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110" style={{ backgroundImage: bg(m.k, i) }} />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-ink/95" />
            <h3 className="relative mb-2 text-3xl transition group-hover:text-cyan2">{m.t}</h3><p className="relative text-sm text-[#b6bdcb]">{m.d}</p>
          </article></Reveal>
        ))}
      </div>
    </div></section>
  );
}
