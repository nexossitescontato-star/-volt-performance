import { CONFIG, bg } from "../../config";
import Btn from "../ui/Btn";
import Reveal from "../ui/Reveal";
export default function Quote() {
  return (
    <section className="relative flex min-h-[70vh] items-center overflow-hidden px-5 py-24 text-center" style={{ backgroundImage: bg("quote", 3), backgroundSize: "cover" }}>
      <div className="absolute inset-0 bg-ink/60" />
      <Reveal className="relative z-10 mx-auto max-w-[1000px]">
        <h2 className="mb-8 text-[clamp(2rem,6.6vw,4.6rem)]">DISCIPLINA NÃO É SOBRE TREINAR QUANDO VOCÊ ESTÁ MOTIVADO.<br /><span className="text-volt">É SOBRE CONTINUAR.</span></h2>
        <Btn href={CONFIG.whatsapp} external>COMECE AGORA</Btn>
      </Reveal>
    </section>
  );
}
