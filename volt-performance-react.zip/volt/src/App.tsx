import Navbar from "./components/Navbar";
import Hero from "./components/sections/Hero";
import Modalidades from "./components/sections/Modalidades";
import Showcase from "./components/sections/Showcase";
import Structure from "./components/sections/Structure";
import Plans from "./components/sections/Plans";
import Team from "./components/sections/Team";
import Quote from "./components/sections/Quote";
import Location from "./components/sections/Location";
import Contact from "./components/sections/Contact";
export default function App() {
  return (
    <>
      <Navbar />
      <Hero />
      <main><Modalidades /><Showcase /><Structure /><Plans /><Team /><Quote /><Location /><Contact /></main>
      <footer className="border-t border-white/10 px-5 py-7 text-center text-xs text-[#8b93a3]">© 2026 VOLT PERFORMANCE · Projeto demonstrativo fictício · Portfólio Nexos Sites</footer>
    </>
  );
}
