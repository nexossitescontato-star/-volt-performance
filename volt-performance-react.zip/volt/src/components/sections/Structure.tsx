import { areas, bg } from "../../config";
import Heading from "../ui/Heading";
import Reveal from "../ui/Reveal";
const span = ["col-span-2 row-span-2 md:col-span-4", "", "", "", "", ""];
export default function Structure() {
  return (
    <section id="estrutura" className="px-5 py-24"><div className="mx-auto max-w-[1160px]">
      <Heading eyebrow="Espaço" title="ESTRUTURA PARA EVOLUIR" lead="Ambientes pensados para performance, conforto e foco." />
      <div className="grid auto-rows-[170px] grid-cols-2 gap-3 md:auto-rows-[190px] md:grid-cols-6">
        {areas.map((a, i) => (
          <Reveal key={a.k} className={`${span[i]} ${i > 0 ? "md:col-span-2" : ""} contents`}>
            <article className={`relative flex flex-col justify-end overflow-hidden border border-white/10 bg-cover p-5 ${span[i]} ${i > 0 ? "md:col-span-2" : ""}`} style={{ backgroundImage: bg(a.k, i + 2) }}>
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-ink/90" />
              <h3 className="relative text-xl">{a.t}</h3><p className="relative text-sm text-[#b6bdcb]">{a.d}</p>
            </article>
          </Reveal>
        ))}
      </div>
    </div></section>
  );
}
