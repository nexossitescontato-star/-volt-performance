import { CONFIG, plans } from "../../config";
import Btn from "../ui/Btn";
import Heading from "../ui/Heading";
export default function Plans() {
  return (
    <section id="planos" className="bg-panel px-5 py-24"><div className="mx-auto max-w-[1160px]">
      <Heading eyebrow="Planos" title="ESCOLHA SEU PLANO" lead="Condições sob consulta, ajustadas ao seu objetivo." />
      <div className="grid gap-4 md:grid-cols-3">
        {plans.map((p) => (
          <article key={p.t} className={`flex flex-col border p-8 transition duration-300 hover:-translate-y-1.5 hover:border-volt ${p.hot ? "border-volt bg-gradient-to-b from-volt/15 to-panel shadow-[0_0_50px_rgba(43,123,255,.18)]" : "border-white/10"}`}>
            {p.hot && <p className="mb-3 text-[.65rem] font-bold tracking-[.2em] text-cyan2">MAIS PROCURADO</p>}
            <h3 className="mb-2.5 text-3xl">{p.t}</h3><p className="mb-6 flex-1 text-[#8b93a3]">{p.d}</p>
            <em className="mb-5 block text-xs uppercase not-italic tracking-[.14em] text-cyan2">Consulte as condições</em>
            <Btn href={CONFIG.whatsapp} external ghost={!p.hot}>QUERO SABER MAIS</Btn>
          </article>
        ))}
      </div>
    </div></section>
  );
}
